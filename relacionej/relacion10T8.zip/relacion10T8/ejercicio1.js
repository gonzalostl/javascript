/*Error en tiempo de ejecución*/

console.log = "El resultado es " + suma;

/*Error en tiempo de desarrollo*/
function error({
   console.log("hola");
}

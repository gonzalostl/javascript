let mensaje1 = "Escribe el primer número:";
let numero1 = prompt(mensaje1);

let mensaje2 = "Escribe el segundo número:";
let numero2 = prompt(mensaje2);

let mensaje3 = "Escribe el tercer número:";
let numero3 = prompt(mensaje3);

let mensaje4 = "Escribe el cuarto número:";
let numero4 = prompt(mensaje4);
let mensaje = "Escribe la longitud de el lado de un cuadrado";
let respuesta = prompt(mensaje);


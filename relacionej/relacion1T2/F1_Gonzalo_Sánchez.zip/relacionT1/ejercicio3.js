let mensaje = "¿Cuál es tu nombre de usuario?";
let respuesta = prompt(mensaje);

let message = "¿Cuál es tu mail?";
let answer = prompt(message);
